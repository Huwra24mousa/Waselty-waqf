
public class Kindergarten extends Beneficiary{
    private int maxOrderItems;

    public Kindergarten(String name, String location, int maxOrderItems) {
        super(name, location);
        this.maxOrderItems = maxOrderItems;
    }

    public int getMaxOrderItems() {
        return maxOrderItems;
    }
}
