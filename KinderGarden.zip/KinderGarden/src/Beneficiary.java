import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class Beneficiary {
    protected String name;
    protected String location;

    public Beneficiary(String name, String location) {
        this.name = name;
        this.location = location;
    }

    public void displayInfo() {
        System.out.println("Name: " + name);
        System.out.println("Location: " + location);
    }
}
