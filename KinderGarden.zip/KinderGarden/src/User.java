public class User extends Beneficiary {
    private String address;

    public User(String name, String address) {
        super(name, "Unknown");
        this.address = address;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Address: " + address);
    }
}
