import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class EducationalResource {
    protected String resourceName;
    protected double cost;

    public int  product_count;

    protected int sell;
    Scanner s=new Scanner(System.in);

    public EducationalResource(String resourceName, double cost,int product_count) {
        this.resourceName = resourceName;
        this.cost = cost;
        this.product_count=product_count;
    }
    public EducationalResource(String resourceName, double cost) {
        this.resourceName = resourceName;
        this.cost = cost;
    }
    public EducationalResource(String resourceName)
    {
        this.resourceName=resourceName;
    }

    public void displayInfo() {
        System.out.println("Resource: " + resourceName);
        System.out.println("Cost: $" + cost);
    }


}
