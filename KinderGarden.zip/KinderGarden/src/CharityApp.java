import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.*;

public class CharityApp {
    // private List<Order> orders;
    private List<Beneficiary> beneficiaries;
    private List<EducationalResource> items;
    private List<EducationalResource> products;
    ////  private List<EducationalResource> orders;

    private Scanner scanner;

    Order order=new Order();

    public CharityApp() {
        beneficiaries = new ArrayList<>();
        products = new ArrayList<>();
        scanner = new Scanner(System.in);
        // orders = new ArrayList<>();
    }

    public void run() {
        int choice;
        do {
            System.out.println("1. user");
            System.out.println("2. client");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine();
            if (choice == 1) {
                manageProducts();

            } else {
                System.out.println("1. view products");
                System.out.println("2. order product");
                System.out.println("3. show orders");
                System.out.println("4. delete order");
                System.out.println("0. Exit");
                System.out.print("Enter your choice: ");
                choice = scanner.nextInt();
                scanner.nextLine();
                switch (choice) {
                    case 1:
                        show_products();
                        break;
                    case 2:
                        order();
                        break;
                    case 3:
                        show_orders();
                        break;
                    case 4:
                        delete_order();
                        break;
                    case 0:
                        System.out.println("Exiting the application. Goodbye!");
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }

        } while (choice != 0);
    }

    private void manageProducts() {
        System.out.println("1. Add Product");
        System.out.println("2. Update Product");
        System.out.println("3. Delete Product");
        System.out.println("4. enter user info");
        System.out.println("5. view best sellers");
        System.out.println("0. Exit");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine();

        switch (choice) {
            case 1:
                addProduct();
                break;
            case 2:
                updateProduct();
                break;
            case 3:
                deleteProduct();
                break;
            case 4:
                enterUserInfo();
                break;
            case 5:
                bestseller();
                break;
            case 0:
                System.out.println("Exiting the application. Goodbye!");
                break;
            default:
                System.out.println("Invalid choice. Returning to the main menu.");
        }
    }

    private void addProduct() {
        System.out.print("Enter product name: ");
        String productName = scanner.nextLine();

        System.out.print("Enter product cost: $");
        double cost = scanner.nextDouble();
        scanner.nextLine();
        System.out.print("Enter product count: ");
        int count= scanner.nextInt();
        EducationalResource newProduct = new EducationalResource(productName, cost,count);
        products.add(newProduct);
        System.out.println("Product added successfully!");
    }

    private void updateProduct() {
        System.out.print("Enter the index of the product to update: ");
        int index = scanner.nextInt();
        scanner.nextLine();

        if (index >= 0 && index < products.size()) {
            System.out.print("Enter new product name: ");
            String newName = scanner.nextLine();

            System.out.print("Enter new product cost: $");
            double newCost = scanner.nextDouble();
            scanner.nextLine();

            EducationalResource updatedProduct = new EducationalResource(newName, newCost);
            products.set(index, updatedProduct);

            System.out.println("Product updated successfully!");
        } else {
            System.out.println("Invalid index. Returning to the main menu.");
        }
    }

    private void deleteProduct() {
        System.out.print("Enter the index of the product to delete: ");
        int index = scanner.nextInt();
        scanner.nextLine();

        if (index >= 0 && index < products.size()) {
            products.remove(index);
            System.out.println("Product deleted successfully!");
        } else {
            System.out.println("Invalid index. Returning to the main menu.");
        }
    }

    private void enterUserInfo() {
        System.out.println("Entering user information...");

        System.out.print("Enter user name: ");
        String userName = scanner.nextLine();

        System.out.print("Enter user address: ");
        String userAddress = scanner.nextLine();

        User newUser = new User(userName, userAddress);
        beneficiaries.add(newUser);

        System.out.println("User information added successfully!");
    }


    private void show_products() {
        for (EducationalResource product : products) {
            product.displayInfo();
            System.out.println("---------------");
        }
    }

    private void order() {
        try{

            boolean found = false;
            System.out.println("enter name of item");
            String choice = scanner.nextLine();
            EducationalResource e = new EducationalResource(choice);
            for (EducationalResource product : products) {
                if (e.resourceName.equals(product.resourceName)) {
                    order.addItem(e);
                    found = true;
                    product.sell++;
                    product.product_count--;
                    if (product.product_count <= 0) {
                        products.remove(product);

                    }
                    break;
                }
            }
            if (found == false) {
                System.out.println("item not found");
            }
        }catch ( Exception e)
        {
            System.out.println(e);
        }
    }
    private void bestseller(){
        int max=-1;
        String productName="";
        for(EducationalResource product : products)
        {
            if(product.sell>max)
            {
                max=product.sell;
            }
            productName=product.resourceName;
        }
        System.out.println("the best seller is:" +productName);

    }
    private void show_orders()
    {
        order.displayOrder();

    }
    private void delete_order()
    {
        items=order.getItems();
        System.out.println("enter name of product");
        String productName = scanner.nextLine();
        for(EducationalResource item:items){
            if(productName.equals(item.resourceName))
            {
                items.remove(item);
                System.out.println("the product delete");
                break;
            }
        }

    }
}
//    private void addDummyData() {
//        beneficiaries.add(new Kindergarten("Kindergarten1", "Jubail", 5));
//        products.add(new EducationalResource("Educational Toy", 10.99));
//        products.add(new EducationalResource("Learning Book", 5.99));
//    }

