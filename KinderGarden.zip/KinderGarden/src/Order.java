import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class Order {
    private List<EducationalResource> items;

    Scanner s=new Scanner(System.in);
    public Order() {
        this.items = new ArrayList<>();
    }

    public void addItem(EducationalResource item) {
        if (items.size() < 5) {
            items.add(item);
            System.out.println("Item added to the order.");
        } else {
            System.out.println("Maximum limit reached. Cannot add more items to the order.");
        }
    }

    public void displayOrder() {
        System.out.println("Order Items:");
        for (EducationalResource item : items) {
            item.displayInfo();
            System.out.println("---------------");
        }
    }

    public List<EducationalResource> getItems() {
        return items;
    }
}
